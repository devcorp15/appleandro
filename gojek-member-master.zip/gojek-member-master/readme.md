# Pendahulan
Aplikasi android untuk member seperti gojek
